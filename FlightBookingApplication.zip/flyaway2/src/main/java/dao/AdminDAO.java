package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.AddFlight;

public class AdminDAO {
	/*String driver="com.mysql.cj.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/n2";
	String user = "root";
	String pass = "Vijay@sql123";*/

	static String driver="com.mysql.cj.jdbc.Driver";
	static String url="jdbc:mysql://localhost:3306/n2";
	static String user = "root";
	static String pass = "Vijay@sql123";
	
	//method to add flight details
public void addFlightDetails(AddFlight addAdmin) throws SQLException{
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/n2";
		String user = "root";
		String pass = "Vijay@sql123";
		
		try 
		{
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url,user,pass);
			PreparedStatement stmt = con.prepareStatement("insert into flightdetails values(?,?,?,?,?,?,?,?)");
			
			stmt.setInt(1, addAdmin.getFlightId());
			stmt.setString(2, addAdmin.getFlightName());
			stmt.setString(3, addAdmin.getSource());
			stmt.setString(4, addAdmin.getDestination());
			stmt.setInt(5, addAdmin.getEconomy());
			stmt.setInt(6, addAdmin.getBusiness());
			stmt.setInt(7, addAdmin.getPremium());
			stmt.setInt(8,addAdmin.getDays());
			stmt.executeUpdate();
			stmt.close();con.close();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

//method to search source and destination

public static AddFlight searchSourceDestination(String source, String Destination) {
	AddFlight addAdmin2 = null ;
	
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("select * from flightdetails where source=? and destination=?");
		
		stmt.setString(1, source);
		stmt.setString(2, Destination);
		
		ResultSet rs= stmt.executeQuery();
		
		while(rs.next()) {
			int flightId = rs.getInt("flightId");
			String flightName = rs.getString("flightName");
			String src = rs.getString("source");
			String dest = rs.getString("destination");
			int economy = rs.getInt("economy");
			int business = rs.getInt("business");
			int premium = rs.getInt("premium");
			int days = rs.getInt("days");
			addAdmin2 = new AddFlight(flightId,flightName,source,Destination,economy,business,premium,days);

			
			addAdmin2.setFlightId(rs.getInt(1));
			addAdmin2.setFlightName(rs.getString(2));
			addAdmin2.setSource(rs.getString(3));
			addAdmin2.setDestination(rs.getString(4));
			addAdmin2.setEconomy(rs.getInt(5));
			addAdmin2.setBusiness(rs.getInt(6));
			addAdmin2.setPremium(rs.getInt(7));
			addAdmin2.setDays(rs.getInt(8));

			
			
		}
	}
	catch (Exception e)
	{
		System.out.println(e.getMessage());
		
	}
	
	return addAdmin2;
}


//method to get economy class fare
public int getClass(String source,String destination,int traveler) {
	int totalFare;
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("select economy from flightdetails where source=? and destination=?");
		
		stmt.setString(1, source);
		stmt.setString(2, destination);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			AddFlight admin = new AddFlight();
			int eco=rs.getInt(1);
			
			admin.setEconomy(eco);
			totalFare = traveler*rs.getInt(1);
	
			return totalFare;
		}
	} catch (Exception e) {
		System.out.println(e.getMessage());
	}
	
	return 0;
}


//method to get business class fare
public int getBusinesClass(String source,String destination,int traveler) {
	int totalFare;
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("select business from flightdetails where source=? and destination=?");
		
		stmt.setString(1, source);
		stmt.setString(2, destination);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			AddFlight admin = new AddFlight();
			int business=rs.getInt(1);
			
			admin.setBusiness(business);
			totalFare = traveler*rs.getInt(1);
	
			return totalFare;
		}
	} catch (Exception e) {
		System.out.println(e.getMessage());
	}
	
	return 0;
}

//method to get premium class fare
public int getPremiumClass(String source,String destination,int traveler) {
	int totalFare;
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("select premium from flightdetails where source=? and destination=?");
		
		stmt.setString(1, source);
		stmt.setString(2, destination);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			AddFlight admin = new AddFlight();
			int pre=rs.getInt(1);
			
			admin.setPremium(pre);
			totalFare = traveler*rs.getInt(1);
	
			return totalFare;
		}
	} catch (Exception e) {
		System.out.println(e.getMessage());
	}
	
	return 0;
}

//method for admin registration
public boolean adminReg(String email,String password) throws ClassNotFoundException, SQLException
{
	try
	{

   	Class.forName(driver);
   	Connection con=DriverManager.getConnection(url,user,pass);
   	PreparedStatement stmt = con.prepareStatement("insert into adminReg values(?,?)");
	
	stmt.setString(1,email);
	stmt.setString(2,password);
	
	int value=stmt.executeUpdate();
	if(value>0)
	{
		return true;
	}
	else
	{
		return false;
	}
	}
	catch(Exception ex)
	{
		System.out.println(ex);
		return false;
	}
	
	
   	
}
//method for admin login
public boolean adminLogin(String email,String password)
{	
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("select * from adminReg where email=? and password=?");
		
		stmt.setString(1, email);
		stmt.setString(2, password);
		
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next()) {
			return true;
		}
	}catch (Exception e) {
		// TODO: handle exception
		System.out.println(e.getMessage());
	}
	
	return false;
}



//method to update admin password
public boolean changePassword(String email,String password)
{
	
	try {
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,user,pass);
		PreparedStatement stmt = con.prepareStatement("update adminReg set password=? where email=?");
		
		stmt.setString(1, password);
		stmt.setString(2, email);
		
		stmt.executeUpdate();
		stmt.close();
	}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println(e.getMessage());
	}

	return false;
}


}
