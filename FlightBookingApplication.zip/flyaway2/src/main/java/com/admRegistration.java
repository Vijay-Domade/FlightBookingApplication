package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.AdminDAO; 
@WebServlet("/admReg")
public class admRegistration extends HttpServlet {
          
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		AdminDAO reg=new AdminDAO();
		try 
		{
			boolean result=reg.adminReg(email,password);
			if(result)
			{
				out.println("<h1>Admin Registered Successfully...</h1>");
				RequestDispatcher r=request.getRequestDispatcher("adminLogin.jsp");
				r.include(request, response);

			}
			else 
			{
				out.println("<h1>Registration Failed</h1>");
				response.sendRedirect("adminRegistration.html");
			}
			
			
		} 
		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
