package com;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.Number;
import java.lang.Object;
import java.util.*;

import model.AddFlight;
import dao.AdminDAO;


@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Registration() {
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*ServletContext context = getServletContext();
		String driver = context.getInitParameter("driver");
		String url = context.getInitParameter("url");
		String username = context.getInitParameter("username");
		String pass = context.getInitParameter("password");
		PrintWriter out = response.getWriter();*/
		
		//Grabing values from html page
		response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
		 String driver="com.mysql.cj.jdbc.Driver";
		 String url="jdbc:mysql://localhost:3306/n2";
		 String username = "root";
		 String pass = "Vijay@sql123";
		 
		
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		String mobileNo=request.getParameter("m");
		//int mobileNo=Integer.parseInt(mo);
		
		try {
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url,username,pass);
			PreparedStatement stmt = con.prepareStatement("insert into userdetails values(?,?,?,?,?)");
			
			stmt.setString(1,firstName);
			stmt.setString(2,lastName);
			stmt.setString(3,email);
			stmt.setString(4,password);
			stmt.setString(5,mobileNo);
			
			stmt.executeUpdate();
			stmt.close();
			con.close();
			
			out.println("<h3 style='color:green'>User Added Succesfully...</h3>");
			response.sendRedirect("payment.html");
		} 
		catch (Exception e) 
		{
			out.println("<h4 style='color:red'>Failed to add User</h4>");
			out.println("<a href='userRegistration.html'>Try Again</a>");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}
